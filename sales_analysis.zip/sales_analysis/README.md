# Sales Data Analysis System

A Flask web application that reads sales data from a CSV file, analyses it with
pandas and shows the results on a dashboard with charts.

## Features
- Key figures: total revenue, units sold, orders, average order value
- Revenue by month, top 5 products, revenue by region and by category
- Upload your own CSV file (validated before it is used)
- Sample data included in `data/sales.csv`

## Run it
```
python -m venv venv
venv\Scripts\activate          # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 in your browser.

## CSV format
Columns: `date, product, category, region, quantity, price` (date as YYYY-MM-DD).

## Files
- `app.py` - Flask routes (dashboard, upload, reset)
- `analysis.py` - pandas functions that load, validate and summarise the data
- `templates/` - HTML pages (`base.html`, `index.html`, `upload.html`)
- `static/style.css` - styling
