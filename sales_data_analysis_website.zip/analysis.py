from pathlib import Path
import pandas as pd
import numpy as np

ALIASES = {
    "date": ["date", "order date", "sales date", "transaction date"],
    "product": ["product", "product name", "item", "item name"],
    "category": ["category", "product category", "type"],
    "region": ["region", "location", "state", "city", "market"],
    "quantity": ["quantity", "qty", "units", "units sold"],
    "unit_price": ["unit price", "price", "selling price", "unit_price"],
    "revenue": ["revenue", "sales", "sales amount", "total sales", "amount", "total"],
    "profit": ["profit", "net profit", "earnings"],
    "order_id": ["order id", "order_id", "invoice", "invoice id", "transaction id"]
}

def normalize_columns(df):
    df = df.copy()
    original = {str(c).strip().lower().replace("_", " "): c for c in df.columns}
    rename = {}
    for canonical, aliases in ALIASES.items():
        for alias in aliases:
            if alias in original:
                rename[original[alias]] = canonical
                break
    df = df.rename(columns=rename)
    if "date" not in df.columns:
        raise ValueError("A date column is required (for example: Date or Order Date).")
    if "product" not in df.columns:
        df["product"] = "Unspecified product"
    if "category" not in df.columns:
        df["category"] = "Uncategorized"
    if "region" not in df.columns:
        df["region"] = "Unspecified region"
    if "quantity" not in df.columns:
        df["quantity"] = 1
    if "revenue" not in df.columns:
        if "unit_price" in df.columns:
            df["revenue"] = pd.to_numeric(df["unit_price"], errors="coerce") * pd.to_numeric(df["quantity"], errors="coerce")
        else:
            raise ValueError("A revenue/sales/amount column is required, or provide both Unit Price and Quantity.")
    if "unit_price" not in df.columns:
        qty = pd.to_numeric(df["quantity"], errors="coerce").replace(0, np.nan)
        df["unit_price"] = pd.to_numeric(df["revenue"], errors="coerce") / qty
    if "profit" not in df.columns:
        df["profit"] = 0
    if "order_id" not in df.columns:
        df["order_id"] = [f"ROW-{i+1:04d}" for i in range(len(df))]
    df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=True)
    for col in ["quantity", "unit_price", "revenue", "profit"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)
    df = df.dropna(subset=["date"])
    if df.empty:
        raise ValueError("No valid dates were found. Use dates such as 2026-01-25.")
    df["quantity"] = df["quantity"].clip(lower=0)
    df["revenue"] = df["revenue"].clip(lower=0)
    for col in ["product", "category", "region", "order_id"]:
        df[col] = df[col].fillna("Unknown").astype(str)
    return df[["date","product","category","region","quantity","unit_price","revenue","profit","order_id"]]

def load_sales(path):
    df = pd.read_csv(path)
    return normalize_columns(df)

def summarize_sales(df):
    if df.empty:
        return dict(revenue=0, units=0, orders=0, average_order=0, profit=0, margin=0)
    revenue = float(df["revenue"].sum())
    orders = int(df["order_id"].nunique())
    profit = float(df["profit"].sum())
    return dict(revenue=revenue, units=int(df["quantity"].sum()), orders=orders,
                average_order=revenue / orders if orders else 0, profit=profit,
                margin=(profit / revenue * 100) if revenue else 0)

def monthly_revenue(df):
    if df.empty: return {"labels": [], "values": []}
    s = df.set_index("date").resample("MS")["revenue"].sum()
    return {"labels": [x.strftime("%b %Y") for x in s.index], "values": [round(float(x), 2) for x in s.values]}

def category_revenue(df):
    if df.empty: return {"labels": [], "values": []}
    s = df.groupby("category")["revenue"].sum().sort_values(ascending=False).head(8)
    return {"labels": s.index.astype(str).tolist(), "values": [round(float(x), 2) for x in s.values]}

def region_revenue(df):
    if df.empty: return {"labels": [], "values": []}
    s = df.groupby("region")["revenue"].sum().sort_values(ascending=False).head(8)
    return {"labels": s.index.astype(str).tolist(), "values": [round(float(x), 2) for x in s.values]}
