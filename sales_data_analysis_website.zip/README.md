# SalesLens — Sales Data Analysis Website

A responsive Flask dashboard for sales data analysis with KPI cards, charts, CSV upload, filters, export, and automatically calculated business insights.

## 1. Setup in VS Code (Windows)

Open this project folder in VS Code and run these commands in the terminal:

```powershell
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 in your browser. Keep the terminal running while you use the website. Press `Ctrl+C` to stop it.

## 2. Project structure

- `app.py` — Flask routes, CSV upload, filters, export
- `analysis.py` — data cleaning and sales calculations
- `templates/` — dashboard, sales table, upload, insights pages
- `static/style.css` — responsive design
- `static/app.js` — interactive Chart.js charts
- `data/sales.csv` — starter sample data

## 3. CSV columns

Required: `Date` and `Revenue` (or `Sales` / `Amount`). Alternatively provide `Date`, `Quantity`, and `Unit Price`.

Recommended: `Product`, `Category`, `Region`, `Quantity`, `Profit`, `Order ID`.

Example:
`Date,Product,Category,Region,Quantity,Unit Price,Revenue,Profit,Order ID`

The app detects common alternate column names. Dates should be recognizable by Pandas, such as `2026-01-25` or `25/01/2026`.

## 4. Features

- Total revenue, units sold, unique orders and average order value
- Monthly revenue trend
- Category and regional charts
- Search and category/region filters
- CSV upload and export
- Best product, region, category and profitability insights
- Responsive desktop and mobile layout

## Notes

- Profit defaults to zero when the source CSV does not provide it. The dashboard does not estimate profit.
- This starter is designed for local/student project use. Before public deployment, configure a strong secret key, add upload-size limits and authentication, and disable Flask debug mode.
- Uploaded data is saved locally as `data/uploaded.csv`. Use **Use sample data** to switch back to the included starter dataset.
