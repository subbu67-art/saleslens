from flask import Flask, render_template, request, redirect, url_for, flash, send_file
from pathlib import Path
import pandas as pd
import io
from analysis import load_sales, summarize_sales, monthly_revenue, category_revenue, region_revenue, normalize_columns

app = Flask(__name__)
app.secret_key = "replace-this-with-a-random-secret-key"
ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)
DEFAULT_FILE = DATA_DIR / "sales.csv"
UPLOADED_FILE = DATA_DIR / "uploaded.csv"
ALLOWED_EXTENSIONS = {".csv"}

def active_file():
    return UPLOADED_FILE if UPLOADED_FILE.exists() else DEFAULT_FILE

def get_data():
    path = active_file()
    try:
        df = load_sales(path)
        return df, None
    except Exception as exc:
        return pd.DataFrame(), str(exc)

@app.route("/")
def dashboard():
    df, error = get_data()
    if error:
        flash(f"Could not load data: {error}", "error")
        df = pd.DataFrame(columns=["date","product","category","region","quantity","unit_price","revenue","profit","order_id"])
    summary = summarize_sales(df)
    return render_template("index.html", summary=summary,
        monthly=monthly_revenue(df), categories=category_revenue(df),
        regions=region_revenue(df), source=active_file().name,
        min_date=df["date"].min().strftime("%d %b %Y") if len(df) else "—",
        max_date=df["date"].max().strftime("%d %b %Y") if len(df) else "—")

@app.route("/sales")
def sales():
    df, error = get_data()
    if error:
        flash(error, "error")
        df = pd.DataFrame()
    query = request.args.get("q", "").strip()
    category = request.args.get("category", "")
    region = request.args.get("region", "")
    if len(df):
        view = df.copy()
        if query:
            mask = view.astype(str).apply(lambda col: col.str.contains(query, case=False, na=False)).any(axis=1)
            view = view[mask]
        if category:
            view = view[view["category"].astype(str) == category]
        if region:
            view = view[view["region"].astype(str) == region]
        categories = sorted(df["category"].dropna().astype(str).unique())
        regions = sorted(df["region"].dropna().astype(str).unique())
        rows = view.sort_values("date", ascending=False).head(500).copy()
        rows["date"] = rows["date"].dt.strftime("%d %b %Y")
        records = rows.fillna("").to_dict("records")
    else:
        categories, regions, records = [], [], []
    return render_template("sales.html", records=records, categories=categories, regions=regions,
                           q=query, selected_category=category, selected_region=region)

@app.route("/insights")
def insights():
    df, error = get_data()
    if error:
        flash(error, "error")
        df = pd.DataFrame()
    if len(df):
        best_product = df.groupby("product", dropna=False)["revenue"].sum().sort_values(ascending=False)
        best_region = df.groupby("region", dropna=False)["revenue"].sum().sort_values(ascending=False)
        best_category = df.groupby("category", dropna=False)["revenue"].sum().sort_values(ascending=False)
        avg_profit = float(df["profit"].mean())
        margin = (df["profit"].sum() / df["revenue"].sum() * 100) if df["revenue"].sum() else 0
        insights_data = {
            "best_product": str(best_product.index[0]) if len(best_product) else "—",
            "best_product_revenue": float(best_product.iloc[0]) if len(best_product) else 0,
            "best_region": str(best_region.index[0]) if len(best_region) else "—",
            "best_region_revenue": float(best_region.iloc[0]) if len(best_region) else 0,
            "best_category": str(best_category.index[0]) if len(best_category) else "—",
            "best_category_revenue": float(best_category.iloc[0]) if len(best_category) else 0,
            "avg_profit": avg_profit, "margin": margin,
            "rows": len(df)
        }
    else:
        insights_data = dict(best_product="—", best_product_revenue=0, best_region="—",
            best_region_revenue=0, best_category="—", best_category_revenue=0,
            avg_profit=0, margin=0, rows=0)
    return render_template("insights.html", insights=insights_data)

@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        file = request.files.get("file")
        if not file or not file.filename:
            flash("Choose a CSV file first.", "error")
            return redirect(url_for("upload"))
        if Path(file.filename).suffix.lower() not in ALLOWED_EXTENSIONS:
            flash("Please upload a .csv file. Excel files are not supported yet.", "error")
            return redirect(url_for("upload"))
        try:
            content = file.read()
            df = pd.read_csv(io.BytesIO(content))
            normalized = normalize_columns(df)
            if normalized.empty:
                raise ValueError("The CSV contains no data rows.")
            # Save original uploaded CSV; normalize on load so the source stays reusable.
            UPLOADED_FILE.write_bytes(content)
            # Validate it can be loaded with required fields.
            load_sales(UPLOADED_FILE)
            flash(f"Upload successful — loaded {len(normalized):,} rows.", "success")
            return redirect(url_for("dashboard"))
        except Exception as exc:
            if UPLOADED_FILE.exists():
                UPLOADED_FILE.unlink()
            flash(f"Upload failed: {exc}", "error")
            return redirect(url_for("upload"))
    return render_template("upload.html")

@app.route("/use-sample")
def use_sample():
    if UPLOADED_FILE.exists():
        UPLOADED_FILE.unlink()
    flash("Sample dataset restored.", "success")
    return redirect(url_for("dashboard"))

@app.route("/export")
def export():
    df, error = get_data()
    if error or df.empty:
        flash("There is no data to export.", "error")
        return redirect(url_for("sales"))
    out = io.BytesIO()
    df.to_csv(out, index=False)
    out.seek(0)
    return send_file(out, mimetype="text/csv", as_attachment=True, download_name="sales_analysis_export.csv")

if __name__ == "__main__":
    app.run(debug=True)
